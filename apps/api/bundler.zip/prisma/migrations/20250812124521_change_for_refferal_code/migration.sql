-- AlterTable
ALTER TABLE `users` MODIFY `referralCode` VARCHAR(191) NULL;
